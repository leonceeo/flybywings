package org.wings.plaf;

import org.wings.SContainer;

public interface ContainerCG<COMPONENT_TYPE extends SContainer> extends ComponentCG<COMPONENT_TYPE> {
    
}
