package org.wings.plaf;

import org.wings.dnd.*;

public interface DragAndDropManagerCG
    extends ComponentCG
{
}
