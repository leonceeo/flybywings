package org.wings.plaf;

import org.wings.SSeparator;

public interface SeparatorCG extends ComponentCG<SSeparator> {

}
